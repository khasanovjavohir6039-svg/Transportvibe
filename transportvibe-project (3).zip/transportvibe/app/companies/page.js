"use client";

import { useState } from "react";
import { tokens as t } from "@/lib/tokens";
import { Icons } from "@/components/icons";
import { Stars, Badge, Btn, Wrap, SectionHead, CompanyCard } from "@/components/shared";
import { companies } from "@/lib/data";
import Nav from "@/components/nav";
import Footer from "@/components/footer";

// ---- PAGE HEADER ----
function PageHeader({ searchTerm, setSearchTerm }) {
  return (
    <section style={{ background: `linear-gradient(165deg, ${t.colors.midnight} 0%, ${t.colors.navy} 60%, ${t.colors.ocean} 100%)`, padding: "48px 0 52px", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, opacity: 0.03, backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)", backgroundSize: "50px 50px" }}/>
      <div style={{ position: "absolute", top: -80, right: -60, width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, rgba(46,125,191,0.12), transparent 70%)" }}/>
      <Wrap style={{ position: "relative", zIndex: 1 }}>
        <div style={{ maxWidth: 600 }}>
          <h1 style={{ fontFamily: t.fonts.display, fontWeight: 800, fontSize: "clamp(28px,4vw,40px)", color: "#fff", letterSpacing: "-0.03em", lineHeight: 1.1, margin: 0 }}>Company <span style={{ color: t.colors.sky }}>Directory</span></h1>
          <p style={{ fontFamily: t.fonts.body, fontSize: 17, color: "rgba(255,255,255,0.65)", marginTop: 12, lineHeight: 1.6 }}>Browse verified auto transport companies. Real profiles, real reviews, real trust scores.</p>
        </div>
        <div style={{ marginTop: 28, display: "flex", gap: 10, maxWidth: 580 }}>
          <div style={{ flex: 1, position: "relative" }}>
            <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: t.colors.slate }}><Icons.Search s={16}/></span>
            <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search by company name, MC#, or DOT#" style={{ width: "100%", padding: "13px 16px 13px 42px", border: "1.5px solid rgba(255,255,255,0.15)", borderRadius: t.radii.md, fontFamily: t.fonts.body, fontSize: 15, color: "#fff", outline: "none", background: "rgba(255,255,255,0.08)", boxSizing: "border-box" }}/>
          </div>
          <div style={{ position: "relative" }}>
            <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: t.colors.slate }}><Icons.MapPin s={16}/></span>
            <input placeholder="Location or route" style={{ width: 200, padding: "13px 16px 13px 42px", border: "1.5px solid rgba(255,255,255,0.15)", borderRadius: t.radii.md, fontFamily: t.fonts.body, fontSize: 15, color: "#fff", outline: "none", background: "rgba(255,255,255,0.08)", boxSizing: "border-box" }}/>
          </div>
        </div>
      </Wrap>
    </section>
  );
}

// ---- FEATURED STRIP ----
function FeaturedStrip() {
  const featured = companies.filter(c => c.featured);
  return (
    <section style={{ padding: "28px 0", background: t.colors.snow, borderBottom: `1px solid ${t.colors.mist}` }}>
      <Wrap>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
          <div style={{ width: 28, height: 28, borderRadius: t.radii.sm, background: "rgba(229,153,62,0.1)", display: "flex", alignItems: "center", justifyContent: "center", color: t.colors.amber }}><Icons.Sparkle s={15}/></div>
          <span style={{ fontFamily: t.fonts.display, fontWeight: 700, fontSize: 15, color: t.colors.midnight }}>Featured & Verified</span>
          <span style={{ fontFamily: t.fonts.body, fontSize: 12.5, color: t.colors.slate, background: t.colors.mist, padding: "2px 8px", borderRadius: t.radii.full }}>Sponsored — clearly labeled, never ranked unfairly</span>
        </div>
        <div style={{ display: "flex", gap: 14, overflowX: "auto", paddingBottom: 4 }}>
          {featured.map(co => (
            <a key={co.id} href={`/companies/${co.id}`} style={{ minWidth: 280, background: "#fff", border: `1.5px solid ${t.colors.cardBorder}`, borderRadius: t.radii.lg, padding: 18, flexShrink: 0, cursor: "pointer", textDecoration: "none" }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <div style={{ width: 44, height: 44, borderRadius: t.radii.md, background: `linear-gradient(135deg,${t.colors.ice},${t.colors.mist})`, display: "flex", alignItems: "center", justifyContent: "center", border: `1px solid ${t.colors.cardBorder}`, color: t.colors.slate, flexShrink: 0 }}><Icons.Truck s={20}/></div>
                <div>
                  <h3 style={{ fontFamily: t.fonts.display, fontWeight: 700, fontSize: 14.5, color: t.colors.midnight, margin: 0 }}>{co.name}</h3>
                  <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 2 }}><Stars rating={co.rating} s={12}/><span style={{ fontFamily: t.fonts.body, fontSize: 12, color: t.colors.slate }}>({co.reviews})</span></div>
                </div>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 10 }}>{co.badges.slice(0, 3).map(b => <Badge key={b} type={b}/>)}</div>
            </a>
          ))}
        </div>
      </Wrap>
    </section>
  );
}

// ---- FILTER BAR ----
function FilterBar({ sortBy, setSortBy, totalResults }) {
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState({});
  const toggleFilter = (key, value) => {
    setActiveFilters(prev => {
      const current = prev[key] || [];
      return { ...prev, [key]: current.includes(value) ? current.filter(v => v !== value) : [...current, value] };
    });
  };
  const activeCount = Object.values(activeFilters).flat().length;

  const Chip = ({ label, cat }) => {
    const active = (activeFilters[cat] || []).includes(label);
    const [h, setH] = useState(false);
    return <button onClick={() => toggleFilter(cat, label)} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: t.radii.full, background: active ? t.colors.azure : h ? t.colors.snow : "#fff", border: `1.5px solid ${active ? t.colors.azure : t.colors.mist}`, color: active ? "#fff" : t.colors.charcoal, fontFamily: t.fonts.display, fontWeight: 500, fontSize: 13, cursor: "pointer", transition: "all 0.2s" }}>{label}{active && <Icons.X s={11}/>}</button>;
  };

  return (
    <div style={{ background: t.colors.white, borderBottom: `1px solid ${t.colors.mist}`, padding: "16px 0" }}>
      <Wrap>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: showFilters ? 16 : 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <span style={{ fontFamily: t.fonts.display, fontWeight: 700, fontSize: 15, color: t.colors.midnight }}>{totalResults} companies</span>
            <button onClick={() => setShowFilters(!showFilters)} style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: t.radii.md, background: showFilters ? t.colors.ice : "transparent", border: `1.5px solid ${showFilters ? t.colors.azure : t.colors.mist}`, color: showFilters ? t.colors.azure : t.colors.charcoal, fontFamily: t.fonts.display, fontWeight: 500, fontSize: 13, cursor: "pointer" }}>
              <Icons.Filter s={14}/> Filters {activeCount > 0 && <span style={{ background: t.colors.azure, color: "#fff", borderRadius: t.radii.full, width: 18, height: 18, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>{activeCount}</span>}
            </button>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontFamily: t.fonts.body, fontSize: 13, color: t.colors.slate }}>Sort by</span>
            <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: "6px 28px 6px 10px", borderRadius: t.radii.md, border: `1.5px solid ${t.colors.mist}`, fontFamily: t.fonts.display, fontWeight: 500, fontSize: 13, color: t.colors.charcoal, background: "#fff", appearance: "none", cursor: "pointer", outline: "none" }}>
              <option value="rating">Highest Rated</option>
              <option value="reviews">Most Reviews</option>
              <option value="name">Name A-Z</option>
            </select>
          </div>
        </div>
        {showFilters && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12, paddingTop: 12, borderTop: `1px solid ${t.colors.mist}` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontFamily: t.fonts.display, fontWeight: 600, fontSize: 12.5, color: t.colors.slate, width: 100, flexShrink: 0, textTransform: "uppercase", letterSpacing: "0.06em" }}>Rating</span>
              <div style={{ display: "flex", gap: 6 }}>{["4.5+", "4.0+", "3.5+", "Any"].map(r => <Chip key={r} label={r} cat="rating"/>)}</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontFamily: t.fonts.display, fontWeight: 600, fontSize: 12.5, color: t.colors.slate, width: 100, flexShrink: 0, textTransform: "uppercase", letterSpacing: "0.06em" }}>Transport</span>
              <div style={{ display: "flex", gap: 6 }}>{["Open", "Enclosed"].map(r => <Chip key={r} label={r} cat="transport"/>)}</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontFamily: t.fonts.display, fontWeight: 600, fontSize: 12.5, color: t.colors.slate, width: 100, flexShrink: 0, textTransform: "uppercase", letterSpacing: "0.06em" }}>Badges</span>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{["Verified", "Top Reviewed", "Customer Favorite", "Premium Experience", "Fast Response", "Strong Support"].map(r => <Chip key={r} label={r} cat="badges"/>)}</div>
            </div>
          </div>
        )}
      </Wrap>
    </div>
  );
}

// ---- PAGINATION ----
function Pagination({ currentPage, totalPages, onPageChange }) {
  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 6, marginTop: 40 }}>
      <button onClick={() => onPageChange(Math.max(1, currentPage - 1))} disabled={currentPage === 1} style={{ width: 38, height: 38, borderRadius: t.radii.md, border: `1.5px solid ${t.colors.mist}`, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: currentPage === 1 ? "not-allowed" : "pointer", opacity: currentPage === 1 ? 0.4 : 1, color: t.colors.charcoal }}><Icons.ChevLeft s={16}/></button>
      {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
        <button key={p} onClick={() => onPageChange(p)} style={{ width: 38, height: 38, borderRadius: t.radii.md, border: p === currentPage ? `1.5px solid ${t.colors.azure}` : `1.5px solid ${t.colors.mist}`, background: p === currentPage ? t.colors.azure : "#fff", color: p === currentPage ? "#fff" : t.colors.charcoal, fontFamily: t.fonts.display, fontWeight: 600, fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>{p}</button>
      ))}
      <button onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))} disabled={currentPage === totalPages} style={{ width: 38, height: 38, borderRadius: t.radii.md, border: `1.5px solid ${t.colors.mist}`, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: currentPage === totalPages ? "not-allowed" : "pointer", opacity: currentPage === totalPages ? 0.4 : 1, color: t.colors.charcoal }}><Icons.ChevRight s={16}/></button>
    </div>
  );
}

// ---- ADVISOR CTA ----
function AdvisorCTA() {
  return (
    <section style={{ padding: "48px 0", background: t.colors.ice }}>
      <Wrap>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 32, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ width: 52, height: 52, borderRadius: t.radii.lg, background: `linear-gradient(135deg,${t.colors.azure},${t.colors.ocean})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", flexShrink: 0 }}><Icons.Sparkle s={24}/></div>
            <div>
              <h3 style={{ fontFamily: t.fonts.display, fontWeight: 700, fontSize: 18, color: t.colors.midnight, margin: 0 }}>Not sure which company is right for you?</h3>
              <p style={{ fontFamily: t.fonts.body, fontSize: 15, color: t.colors.graphite, margin: "4px 0 0" }}>Let TransportVibe AI match you with the best fit based on your route, vehicle, and priorities.</p>
            </div>
          </div>
          <Btn v="primary" sz="lg" icon={<Icons.Arrow s={18}/>} href="/advisor">Try the Advisor</Btn>
        </div>
      </Wrap>
    </section>
  );
}

// ---- MAIN PAGE ----
export default function CompanyDirectoryPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("rating");
  const [currentPage, setCurrentPage] = useState(1);

  let filtered = companies.filter(co => co.name.toLowerCase().includes(searchTerm.toLowerCase()));
  if (sortBy === "rating") filtered.sort((a, b) => b.rating - a.rating);
  if (sortBy === "reviews") filtered.sort((a, b) => b.reviews - a.reviews);
  if (sortBy === "name") filtered.sort((a, b) => a.name.localeCompare(b.name));

  const perPage = 9;
  const totalPages = Math.ceil(filtered.length / perPage);
  const pageCompanies = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);

  return (
    <div style={{ background: t.colors.snow, minHeight: "100vh" }}>
      <Nav activePage="Companies"/>
      <PageHeader searchTerm={searchTerm} setSearchTerm={setSearchTerm}/>
      <FeaturedStrip/>
      <FilterBar sortBy={sortBy} setSortBy={setSortBy} totalResults={filtered.length}/>

      <section style={{ padding: "32px 0 60px" }}>
        <Wrap>
          {pageCompanies.length > 0 ? (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20 }}>
                {pageCompanies.map(co => <CompanyCard key={co.id} co={co} showMeta/>)}
              </div>
              {totalPages > 1 && <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage}/>}
            </>
          ) : (
            <div style={{ textAlign: "center", padding: "60px 20px" }}>
              <div style={{ width: 64, height: 64, borderRadius: t.radii.full, background: t.colors.mist, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", color: t.colors.slate }}><Icons.Search s={28}/></div>
              <h3 style={{ fontFamily: t.fonts.display, fontWeight: 700, fontSize: 20, color: t.colors.midnight, margin: "0 0 8px" }}>No companies found</h3>
              <p style={{ fontFamily: t.fonts.body, fontSize: 15, color: t.colors.graphite, maxWidth: 400, margin: "0 auto 24px" }}>Try adjusting your search or filters. You can also try the Advisor — it'll match you with the right company.</p>
              <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
                <Btn v="secondary" sz="md" onClick={() => setSearchTerm("")}>Clear Search</Btn>
                <Btn v="primary" sz="md" icon={<Icons.Arrow s={16}/>} href="/advisor">Try the Advisor</Btn>
              </div>
            </div>
          )}
        </Wrap>
      </section>

      <AdvisorCTA/>
      <Footer/>
    </div>
  );
}
